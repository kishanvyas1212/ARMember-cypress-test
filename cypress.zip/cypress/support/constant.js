// support/constants.js
export const URL = 'https://testhashirama.ct.ws/';
export const username_exist_msg ="This username is already registered, please choose another one."
export const useremail_exist_msg ="This email is already registered, please choose another one."
export const admin_pass="4Gxytze4T5purzJaJ$jK9sS3r"
export const admin_username="jaydeep"
export const basic_signup_fix_redirection_specific_page_url=URL+"edit_profile/"
export const basic_signup_fix_redirection_specific_url = URL+"test/"
// ... other constants