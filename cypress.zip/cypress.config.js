const { defineConfig } = require("cypress");

module.exports = defineConfig({
  e2e: {
    setupNodeEvents(on, config) {
      // implement node event listeners here
      on('task', {
        openNewTab: () => {
          return cy.window().then((win) => {
            win.open("", "_blank");
          });
        },
      });
    },
    specPattern: 'cypress/integration/**/*.spec.{js,ts,jsx,tsx}',
  },
});
